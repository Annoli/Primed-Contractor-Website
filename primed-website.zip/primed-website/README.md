# primedcontractor.com

Files: `index.html` (homepage), `privacy.html`, `terms.html`.

## Put it live
1. Make a new GitHub repository (e.g. `primed-website`) and upload these 3 files.
2. In Vercel: Add New Project, then import that repository, then Deploy.
3. In Vercel, open the project, go to Settings, then Domains, and add `primedcontractor.com`. Vercel shows the DNS records to add at your domain registrar.

## Edit your details
Open `index.html` and edit the `SITE` block near the top:
- `phone`, `email`
- `bookingUrl`: your GoHighLevel/Calendly booking link. All "Get my free preview" buttons will open it.
- `leadWebhook`: GoHighLevel inbound webhook URL. The contact form sends name, company, phone, email, trade, website and SMS consent to it.
- `founder.photo`: upload your photo (e.g. `adam.jpg`) to the repo and put the file name here.
- `testimonials`: add real ones and the Results section appears automatically.

## Notes
- The chat bubble is a scripted demo assistant. You can later swap it for your GoHighLevel chat widget by pasting their embed code before `</body>`.
- The SMS consent checkbox and Privacy/Terms pages are there because carriers require them for business texting (A2P 10DLC). Have an attorney review both pages.
- Only publish reviews and results that are real.
